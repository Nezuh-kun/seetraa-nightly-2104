JSON for Modern C++
===================

v3.9.0

This is a mirror providing the single required header file.

The original repository can be found at:
https://github.com/nlohmann/json/commit/d34771cafc87b358ba421faca28facc7f8080174
